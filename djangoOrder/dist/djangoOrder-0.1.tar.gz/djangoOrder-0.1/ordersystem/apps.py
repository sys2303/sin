from django.apps import AppConfig


class OrdersystemConfig(AppConfig):
    name = 'ordersystem'
